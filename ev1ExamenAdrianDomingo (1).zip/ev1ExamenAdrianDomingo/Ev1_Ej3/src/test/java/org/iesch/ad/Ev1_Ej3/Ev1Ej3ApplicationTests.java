package org.iesch.ad.Ev1_Ej3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ev1Ej3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
